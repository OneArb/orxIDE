// ImGui - standalone example application for GLFW + OpenGL2, using legacy fixed pipeline
// If you are new to ImGui, see examples/README.txt and documentation at the top of imgui.cpp.
// (GLFW is a cross-platform general purpose library for handling windows, inputs, OpenGL/Vulkan graphics context creation, etc.)

// **DO NOT USE THIS CODE IF YOUR CODE/ENGINE IS USING MODERN OPENGL (SHADERS, VBO, VAO, etc.)**
// **Prefer using the code in the opengl3_example/ folder**
// See imgui_impl_glfw.cpp for details.

// OrxIDE main002.c - morph test application from ImGui 1.63 WIP to 1.75 WIP

// https://github.com/ocornut/imgui/wiki

#include "imgui.h"
#include <stdio.h>
#include <cstdint>

#include <iostream>
#include <fstream>

using namespace std;

#include "ImGui_Orx.h"
extern "C"
    {
#include <orx.h>
#include <orx.h>
    }

#ifdef UNUSED
#elif defined(__GNUC__)
# define UNUSED(x) UNUSED_ ## x __attribute__((unused))
#elif defined(__LCLINT__)
# define UNUSED(x) /*@unused@*/ x
#elif defined(__cplusplus)
# define UNUSED(x)
#else
# define UNUSED(x) x
#endif

#define PHI 1.618033988749895
#define BLANK_LINE ImGui::Text(" ");
#define TAB "\t"

// log orxIDE Config calls
//#define DEBUG_LOG_STREAM

// log using ImGui log function
//#define DEBUG_LOG_IMGUI

orxVIEWPORT * gpstMainViewport = orxNULL;
orxCAMERA * gpstMainCamera = orxNULL;

//////////////////////////////////////////////////////////////////////////
// segregate all orxIDE static variables from boilerplate ImGui code
namespace orxIDEconfig {

  const orxSTRING key = "widget";
  const orxSTRING val = "ImGuiText";

  const orxSTRING File = "orxTest.ini";
  const orxSTRING ConfigFileMissing = "Config file missing";
  orxBOOL ConfigFileMissingFlag = false;
}

namespace orxIDEstatus {

  bool defaults_load_need = true; // default settings load need

  bool show_Neo = true; // show Neo test window
  bool configcreate = false; // init config render orxIDE
  bool editrender = false;  // render edited orxIDE config

  bool show_orxIDE = true; // show orxIDE window
  bool show_demo_window  = false; // show ImGui demp
  bool show_style_editor = false; // show Style Editor
  bool show_about_window = false; // show show About Window
  bool show_metrics_window = false; // show show Metrics Window
}

#define ORXIDE_WIN_TITLE orxIDE::key_str[orxIDE::windowTitle]
#define ORXIDE_TEXT orxIDE::key_str[orxIDE::text]
#define ORXIDE_SEPARATOR orxIDE::key_str[orxIDE::separator]
#define ORXIDE_CHECKBOX orxIDE::key_str[orxIDE::checkBox]
#define ORXIDE_BUTTON orxIDE::key_str[orxIDE::button]
#define ORXIDE_TEXTMULTI orxIDE::key_str[orxIDE::multiText]

#define ORXIDE_SECTION_ORXIDE orxIDE::section_str[orxIDE::section_orxIDE]

namespace orxIDE {

  orxU32 orxSTATUS; // save status

  char const spacer[] = " ";
  char const * null = "";
  char const * stringFormat = "%s";

  float WindowWidth = 530;
  float WindowHeigth = 750;
  float Xpos = 450;
  float Ypos = 10;

  float WindowWidthNew  = 161 * PHI;
  float WindowHeigthNew = 161;

  float XposNew = 50;
  float YposNew = 10;

  ImGuiWindowFlags window_flags = 0;

  ImVec4 const green  = ImColor(0, 255,   0, 200);
  ImVec4 const yellow = ImColor(0,   0, 255, 200);
  ImVec4 const red    = ImColor(255, 0,   0, 200);

  enum section_ {
    section_resource,
    section_orxIDE,
    section_COUNT
  };

  char const * section_str[section_COUNT] = {
    "resource",
    "orxIDE"
  };

  enum key_ {
    windowTitle, // ImGui::Begin(orxIDE::windowTitle, &orxIDEstatus::show_demo_window, orxIDE::window_flags);
    text,        // Text(const char* fmt, ...)
    separator,
    checkBox,
    button,
    multiText,
    key_COUNT
  };

  char const * key_str[key_COUNT] = {
    "windowTitle",
    "text",
    "separator",
    "checkBox",
    "button",
    "multiText"
  };

  size_t const key_len[key_COUNT] = {
     strlen(ORXIDE_WIN_TITLE),
     strlen(ORXIDE_TEXT),
     strlen(ORXIDE_SEPARATOR),
     strlen(ORXIDE_CHECKBOX),
     strlen(ORXIDE_BUTTON),
     strlen(ORXIDE_TEXTMULTI)
  };

  // temporary variable used to display ImGui widget

  bool TMPcheckBoxFlag;        // ImGui::Checkbox

// ImGui::InputTextMultiline
  char TMPtext[1024 * 16]="";
  static ImGuiInputTextFlags TMPflags = ImGuiInputTextFlags_AllowTabInput;

  enum text_ {
    Hello,
    text_COUNT
  };

  char const * text_str[text_COUNT] = {
    "orxIDE - Hello orx team"
  };

  orxU32 const str_output = UINT32_MAX;

#ifdef DEBUG_LOG_STREAM
  ofstream errorMsgFile;
  char const * errorMsgFileName = "errorMsgFile.txt";
#endif

#ifdef DEBUG_LOG_IMGUI
  const char* ImLogFile = "ImLogFile.txt";
#endif

}

namespace orxIDEf { // function pointer set

// argument type set
struct argSet
{
    union {
      struct {
        const char* fmt; // 8 bytes
        const char* str;
      } text ;
      struct {
        const char* label; // 8 bytes
        bool* v;
      } checkbox;
    };
} arg[20]={};// initialize to null


bool checkBoxFlag[10];
static size_t checkBoxIndice = 0;

// Widget variable set
struct widgetVarSet
{
    union {
      struct {
      } ;
      struct {
        bool flag;
      } checkBox;
    };
} warg[50]={};// initialize to null

void argStruInit(void) {

  orxIDEf::arg[orxIDE::windowTitle].text.fmt = orxIDE::null;
  orxIDEf::arg[orxIDE::windowTitle].text.str = orxIDE::null;

  orxIDEf::arg[orxIDE::text].text.fmt = orxIDE::stringFormat;
  orxIDEf::arg[orxIDE::text].text.str = orxIDE::null;

  orxIDEf::arg[orxIDE::separator].text.fmt = orxIDE::null;
  orxIDEf::arg[orxIDE::separator].text.str = orxIDE::null;

  orxIDEf::arg[orxIDE::checkBox].checkbox.label = orxIDE::null;
  orxIDEf::arg[orxIDE::checkBox].checkbox.v = nullptr; // placeholder
}
// place holder function for windowTitle
void windowTitle(const void *, const void *) {
}
//void windowTitle(void*, void*) {
//}

// wrapper function ImGui::Text
void Text(const void * str, const void * fmt ) {
  ImGui::Text((char *) fmt, (char *) str);
}
// wrapper function ImGui::Separator
void Separator(const void *, const void *) {
  ImGui::Separator();
}
// wrapper function ImGui::Checkbox
void Checkbox(const void * label, const void * v) {
  ImGui::Checkbox((char *) label, &orxIDEf::checkBoxFlag[orxIDEf::checkBoxIndice]);
}
// wrapper function ImGui::Separator
void (*fp[]) (const void *, const void *) =
  {
    windowTitle,
    Text,
    Separator,
    Checkbox
  };
}

// append error messages to file
#ifdef DEBUG_LOG_STREAM

void _debugFileStreamBlank() {

  orxIDE::errorMsgFile.open(orxIDE::errorMsgFileName);
}
void _debugFileStreamAppend() {

  orxIDE::errorMsgFile.open(orxIDE::errorMsgFileName, std::ios::app);
}
void _debugFileStreamClose() {

  orxIDE::errorMsgFile.close();
}
#endif
//////////////////////////////////////////////////////////////////////////
void ImGuiOrx_ResizeViewport()
    {
    orxFLOAT scr_w, scr_h;
    orxDisplay_GetScreenSize(&scr_w, &scr_h);

    orxFLOAT vwp_w, vwp_h;
    orxViewport_GetSize(gpstMainViewport, &vwp_w, &vwp_h);

    orxAABOX frustum;
    orxCamera_GetFrustum(gpstMainCamera, &frustum);

    orxVECTOR cam_pos;
    orxCamera_GetPosition(gpstMainCamera, &cam_pos);
    orxCamera_SetFrustum(gpstMainCamera, vwp_w, vwp_h, frustum.vTL.fZ, frustum.vBR.fZ);
    orxCamera_SetPosition(gpstMainCamera, &cam_pos);

    orxDEBUG_PRINT(orxDEBUG_LEVEL_LOG, "Viewport Size : %f, %f", vwp_w, vwp_h);
    }

//////////////////////////////////////////////////////////////////////////
orxSTATUS orxFASTCALL ImGuiOrx_EventHandler(const orxEVENT *_pstEvent)
    {
    switch (_pstEvent->eType)
        {
        case orxEVENT_TYPE_RENDER:
            {
            /* we render ImGui stuff on the top so we call it at the end of Orx frame rendering cycle */
            if (_pstEvent->eID == orxRENDER_EVENT_STOP)
                ImGui_Orx_Render(NULL, ImGui::GetDrawData());
            }
            break;

        case orxEVENT_TYPE_DISPLAY:
            ImGuiOrx_ResizeViewport();
            break;

        default:
            break;
        }

    return orxSTATUS_SUCCESS;
    }

//////////////////////////////////////////////////////////////////////////
orxSTATUS orxFASTCALL ImGuiOrx_Init()
    {
    // Setup Dear ImGui binding
    IMGUI_CHECKVERSION();

    /* create the gui context */
    ImGui::CreateContext();

    /* initialize the gui port */
    ImGui_Orx_Init();

    /* add events to manage */
    orxEvent_AddHandler(orxEVENT_TYPE_RENDER, ImGuiOrx_EventHandler);
    orxEvent_AddHandler(orxEVENT_TYPE_VIEWPORT, ImGuiOrx_EventHandler);
    orxEvent_AddHandler(orxEVENT_TYPE_DISPLAY, ImGuiOrx_EventHandler);

    // Setup style
    ImGui::StyleColorsDark();
    //ImGui::StyleColorsClassic();

    // Load Fonts
    // - If no fonts are loaded, dear imgui will use the default font. You can also load multiple fonts and use ImGui::PushFont()/PopFont() to select them.
    // - AddFontFromFileTTF() will return the ImFont* so you can store it if you need to select the font among multiple.
    // - If the file cannot be loaded, the function will return NULL. Please handle those errors in your application (e.g. use an assertion, or display an error and quit).
    // - The fonts will be rasterized at a given size (w/ oversampling) and stored into a texture when calling ImFontAtlas::Build()/GetTexDataAsXXXX(), which ImGui_ImplXXXX_NewFrame below will call.
    // - Read 'misc/fonts/README.txt' for more instructions and details.
    // - Remember that in C/C++ if you want to include a backslash \ in a string literal you need to write a double backslash \\ !
    //io.Fonts->AddFontDefault();
    //io.Fonts->AddFontFromFileTTF("../../misc/fonts/Roboto-Medium.ttf", 16.0f);
    //io.Fonts->AddFontFromFileTTF("../../misc/fonts/Cousine-Regular.ttf", 15.0f);
    //io.Fonts->AddFontFromFileTTF("../../misc/fonts/DroidSans.ttf", 16.0f);
    //io.Fonts->AddFontFromFileTTF("../../misc/fonts/ProggyTiny.ttf", 10.0f);
    //ImFont* font = io.Fonts->AddFontFromFileTTF("c:\\Windows\\Fonts\\ArialUni.ttf", 18.0f, NULL, io.Fonts->GetGlyphRangesJapanese());
    //IM_ASSERT(font != NULL);

    // Creates main viewport
    gpstMainViewport = orxViewport_CreateFromConfig("MainViewport");

    // Gets main camera
    gpstMainCamera = orxViewport_GetCamera(gpstMainViewport);

    return orxSTATUS_SUCCESS;
    }

// Helper to display a little (?) mark which shows a tooltip when hovered.
static void ShowHelpMarker(const char* desc)
{
    ImGui::TextDisabled("(?)");
    if (ImGui::IsItemHovered())
    {
        ImGui::BeginTooltip();
        ImGui::PushTextWrapPos(ImGui::GetFontSize() * 35.0f);
        ImGui::TextUnformatted(desc);
        ImGui::PopTextWrapPos();
        ImGui::EndTooltip();
    }
}

orxU32 orxFASTCALL orxIDELog2Screen(orxU32 func_result, char const * func_str = orxNULL ,char const * result_str = "")
    {

      orxIDE::orxSTATUS = func_result;

#ifdef DEBUG_LOG_STREAM
      _debugFileStreamAppend();

      orxIDE::errorMsgFile << func_str << endl;

       _debugFileStreamClose();
#endif

#ifdef DEBUG_LOG_IMGUI
      ImGui::LogText("%s", func_str);
#endif

      if (func_result != orxIDE::str_output)
            ImGui::Text("%4d", func_result );

      ImGui::NextColumn();

      if (func_str == orxNULL) {
          ImGui::NextColumn();
          ImGui::NextColumn();
      }
      else {
        ImGui::Text("%s", func_str);
        ImGui::SameLine();
      }

//      ImGui::SetCursorPosX((ImGui::GetCursorPosX() +5));
      ImGui::TextColored(orxIDE::green, "%s", result_str);
      ImGui::NextColumn();

      return func_result;

    }
// clear orx Config stack
void orxIDEclear_stack() {

  orxIDELog2Screen((orxU32) orxConfig_Clear (nullptr)
                          ,"orxConfig_Clear (nullptr)"
                          ,"empty stack");
}
// Save or create orxIDE Config
void orxIDEConfig_Save() {
  orxIDELog2Screen((orxU32)  orxConfig_Save(orxIDEconfig::File, orxFALSE ,orxNULL)
                           ,"orxConfig_Save(orxIDEconfig::File, orxFALSE ,orxNULL)"
                           ,"Save Config file");
}
// create orxIDE Config section
void orxIDECreate_orxIDEsection() {

  orxIDELog2Screen((orxU32)   orxConfig_PushSection(ORXIDE_SECTION_ORXIDE)
                            ,"orxConfig_PushSection(ORXIDE_SECTION_ORXIDE)");

  orxIDELog2Screen(orxIDE::str_output, orxIDE::spacer, "create [orxIDE] section");

  // set windowTitle to "orxIDE"
  orxIDELog2Screen((orxU32)   orxConfig_SetStringBlock(ORXIDE_WIN_TITLE, orxIDE::text_str[orxIDE::Hello])
                            ,"orxConfig_SetStringBlock(ORXIDE_WIN_TITLE, ORXIDE_SECTION_ORXIDE)");

  orxIDEConfig_Save();

}
// load orxIDE Config
void orxIDEConfig_Load() {

// 2020-01-01 at this time loading a non-existent config file
// results in a core dumped

  if (!orxIDELog2Screen((orxU32) orxConfig_Load(orxIDEconfig::File)
                          ,"orxConfig_Load(orxIDEconfig::File)"
                          ,"load config file")

      || orxIDEconfig::ConfigFileMissingFlag)
    {

      if (!orxIDEconfig::ConfigFileMissingFlag) { // execute once

        cout << orxIDEconfig::File << orxIDE::spacer << orxIDEconfig::ConfigFileMissing << endl;

#ifdef DEBUG_LOG_STREAM

        _debugFileStreamAppend();

        orxIDE::errorMsgFile << orxIDEconfig::File << orxIDE::spacer << orxIDEconfig::ConfigFileMissing << endl;

        _debugFileStreamClose();

//    assert((orxIDEconfig::ConfigFileMissing ,false));
#endif

#ifdef DEBUG_LOG_IMGUI
        ImGui::LogText("%s %s", orxIDEconfig::ConfigFileMissing, orxIDEconfig::File);
#endif
        orxIDECreate_orxIDEsection(); // attempt to recover
      }

      // execute each frame

      orxIDELog2Screen(orxIDE::str_output, orxIDE::spacer, "create missing Config file");
      orxIDELog2Screen(orxIDE::str_output, orxIDE::spacer, orxIDEconfig::File);

      orxIDEconfig::ConfigFileMissingFlag = true; // keep information on screen log till orxIDETestrender() exit
    }
}
// Select section [orxIDE]
void orxFASTCALL orxIDESelectSection_orxIDE() {

  orxIDELog2Screen((orxU32) orxConfig_HasSection(ORXIDE_SECTION_ORXIDE)
                          ,"orxConfig_HasSection(ORXIDE_SECTION_ORXIDE)"
                          ,"Check [orxIDE] section exists");

  if (orxIDE::orxSTATUS) // set by last orx function call
      orxIDELog2Screen((orxU32) orxConfig_SelectSection(ORXIDE_SECTION_ORXIDE),
                               "orxConfig_SelectSection(ORXIDE_SECTION_ORXIDE)",
                               "select [orxIDE] section" );
}
// Get [orxIDE] windowTitle
void orxIDEGetWindow_title() {

  orxIDELog2Screen(orxIDE::str_output
                 ,"orxConfig_GetString(ORXIDE_WIN_TITLE)"
          ,(char*) orxConfig_GetString(ORXIDE_WIN_TITLE));

  orxIDELog2Screen(orxIDE::str_output ,orxIDE::spacer
                  ,"retrieve windowTitle in [orxIDE] section");
}

void orxIDEinitRender() {

  orxIDELog2Screen(orxIDE::str_output, orxNULL, "*** Start render");

  orxIDEclear_stack();
  orxIDEConfig_Load();
  orxIDESelectSection_orxIDE();
}
// ensure string never null
const char * SpaceIfEmpty(const char * str ){

  return((strlen(str)) ? str : orxIDE::spacer);
}
void orxFASTCALL orxIDEconfigParseEval(){
// Eval loop
// orxConfig_GetKeyCount()
// orxSTRING orxConfig_GetKey ( orxU32 _u32KeyIndex	)

  orxIDELog2Screen((orxU32)  orxConfig_GetSectionCount()
                           ,"orxConfig_GetSectionCount()");

    orxU32 orxIDESectionwidgetcount = orxConfig_GetKeyCount();


    orxIDELog2Screen((orxU32)  orxIDESectionwidgetcount
                             ,"orxConfig_GetKeyCount()");

  // initiate window
  ImGui::Begin(SpaceIfEmpty(orxConfig_GetString(ORXIDE_WIN_TITLE))
             ,&orxIDEstatus::configcreate, orxIDE::window_flags);

 orxIDEf::arg[0].text.str = "%s";


//       static bool animate = true;
//       ImGui::Checkbox("Animate", &animate);


            static char text[1024 * 16] =
                "/*\n"
                " The Pentium F00F bug, shorthand for F0 0F C7 C8,\n"
                " the hexadecimal encoding of one offending instruction,\n"
                " more formally, the invalid operand with locked CMPXCHG8B\n"
                " instruction bug, is a design flaw in the majority of\n"
                " Intel Pentium, Pentium MMX, and Pentium OverDrive\n"
                " processors (all in the P5 microarchitecture).\n"
                "*/\n\n"
                "label:\n"
                "\tlock cmpxchg8b eax\n";

            static ImGuiInputTextFlags flags = ImGuiInputTextFlags_AllowTabInput;
            // HelpMarker("You can use the ImGuiInputTextFlags_CallbackResize facility if you need to wire InputTextMultiline() to a dynamic string type. See misc/cpp/imgui_stdlib.h for an example. (This is not demonstrated in imgui_demo.cpp)");
//            ImGui::CheckboxFlags("ImGuiInputTextFlags_ReadOnly", (unsigned int*)&flags, ImGuiInputTextFlags_ReadOnly);
//            ImGui::CheckboxFlags("ImGuiInputTextFlags_AllowTabInput", (unsigned int*)&flags, ImGuiInputTextFlags_AllowTabInput);
//            ImGui::CheckboxFlags("ImGuiInputTextFlags_CtrlEnterForNewLine", (unsigned int*)&flags, ImGuiInputTextFlags_CtrlEnterForNewLine);
//            ImGui::InputTextMultiline("##source", text, IM_ARRAYSIZE(text), ImVec2(-FLT_MIN, ImGui::GetTextLineHeight() * 16), flags);


  { // render Config [orxIDE] section widget set

    orxU32 orxIDEwidgetcount = 0;

    while (orxIDEwidgetcount <= orxIDESectionwidgetcount) {

      int orxIDEwidgetkey = 0;
      // find orxIDE::key_
      while (orxIDEwidgetkey <= orxIDE::key_COUNT) {

//        printf("\norxIDEwidgetcount %d %s ", orxIDEwidgetcount, orxConfig_GetKey(orxIDEwidgetcount));
//        printf("orxIDEwidgetkey %u - %s ", orxIDEwidgetkey, (orxSTRING) orxIDE::key_str[orxIDEwidgetkey]);
//        printf("\n   key_len %d", (int) orxIDE::key_len[orxIDEwidgetkey]);
//        orxLOG(" strncmp %d", strncmp(orxConfig_GetKey(orxIDEwidgetcount),
//                   (orxSTRING) orxIDE::key_str[orxIDEwidgetkey],
//                    orxIDE::key_len[orxIDEwidgetkey]));

        if (!strncmp(orxConfig_GetKey(orxIDEwidgetcount),
                   (orxSTRING) orxIDE::key_str[orxIDEwidgetkey],
                    orxIDE::key_len[orxIDEwidgetkey]))
          {

//            printf(" equal\n");
            break;
          }
        orxIDEwidgetkey++;
      }

//      ImGui::Text("%s", SpaceIfEmpty(orxConfig_GetString(ORXIDE_WIN_TITLE)));

      switch (orxIDEwidgetkey) {
        case orxIDE::windowTitle :

          orxIDEf::arg[orxIDEwidgetkey].text.str = orxConfig_GetString(orxConfig_GetKey(orxIDEwidgetcount));

          orxIDEf::fp[orxIDEwidgetkey](orxIDEf::arg[orxIDEwidgetkey].text.str,
                                       orxIDEf::arg[orxIDEwidgetkey].text.fmt);
          break;

        case orxIDE::text :

          orxIDEf::arg[orxIDEwidgetkey].text.str = orxConfig_GetString(orxConfig_GetKey(orxIDEwidgetcount));

          orxIDEf::fp[orxIDEwidgetkey](orxIDEf::arg[orxIDEwidgetkey].text.str,
                                       orxIDEf::arg[orxIDEwidgetkey].text.fmt);
//          ImGui::Text("%s", orxConfig_GetString(orxConfig_GetKey(orxIDEwidgetcount)));
//          printf("\nswitch text widget: %s", orxConfig_GetKey(orxIDEwidgetcount));
          break;

        case orxIDE::separator :

//          ImGui::Separator();
//            (*orxIDEf::Separator)();

          orxIDEf::arg[orxIDEwidgetkey].text.str = orxConfig_GetString(orxConfig_GetKey(orxIDEwidgetcount));

          orxIDEf::fp[orxIDEwidgetkey](orxIDEf::arg[orxIDEwidgetkey].text.str,
                                       orxIDEf::arg[orxIDEwidgetkey].text.fmt);

//           orxIDEf::Separator(orxIDE::null, orxIDE::null);

          break;

        case orxIDE::checkBox :

          orxIDEf::arg[orxIDE::checkBox].checkbox.label = orxConfig_GetString(orxConfig_GetKey(orxIDEwidgetcount));

          orxIDEf::fp[orxIDEwidgetkey]( orxIDEf::arg[orxIDE::checkBox].checkbox.label,
                                        orxIDEf::arg[orxIDE::checkBox].checkbox.v );


//          ImGui::Checkbox( orxConfig_GetString(orxConfig_GetKey(orxIDEwidgetcount)),
//                          &orxIDE::TMPcheckBoxFlag);
          break;

        case orxIDE::button :

          ImGui::Button(orxConfig_GetString(orxConfig_GetKey(orxIDEwidgetcount)));
          break;

        case orxIDE::multiText :

          strcpy(orxIDE::TMPtext, orxConfig_GetString(orxConfig_GetKey(orxIDEwidgetcount)));

          ImGui::InputTextMultiline("##source",
                                    orxIDE::TMPtext,
                                    IM_ARRAYSIZE(orxIDE::TMPtext),
                                    ImVec2(-FLT_MIN, ImGui::GetTextLineHeight() * 16),
                                    orxIDE::TMPflags);

//          ImGui::InputTextMultiline("##source",
//                                    text,
//                                    IM_ARRAYSIZE(text),
//                                    ImVec2(-FLT_MIN, ImGui::GetTextLineHeight() * 16),
//                                    flags);
          break;

        default :
          ; //ImGui::Text("%s", orxConfig_GetString(ORXIDE_TEXT));
          // printf("\norxIDEwidgetkey %d",orxIDEwidgetkey);
      }

      orxIDEwidgetcount++;
    }
  }

}
orxSTATUS orxFASTCALL orxIDEwindowRender() {

  orxIDEGetWindow_title();

  ImGui::SetNextWindowPos(ImVec2(orxIDE::XposNew, orxIDE::YposNew));
  ImGui::SetNextWindowSize(ImVec2(orxIDE::WindowWidthNew, orxIDE::WindowHeigthNew), ImGuiCond_FirstUseEver);

  orxIDE::window_flags = 0;

//  orxIDE::window_flags |= ImGuiWindowFlags_NoCollapse;
//        orxIDE::window_flags |= ImGuiWindowFlags_NoMove;

  // Begin render
  orxIDEconfigParseEval();

  ImGui::End();

  return orxSTATUS_SUCCESS;
}
void orxIDEinitTestrender() {

  orxIDEclear_stack();

  orxIDELog2Screen((orxU32)   orxConfig_GetSectionCount()
                            ,"orxConfig_GetSectionCount()"
                            , "verify stack empty");

  orxIDECreate_orxIDEsection();



  orxIDELog2Screen(orxIDE::str_output, orxIDE::spacer ,"ORXIDE_WIN_TITLE - create windowTitle key");

  orxIDELog2Screen( orxIDE::str_output, "orxConfig_GetSection((orxU32) orxIDE::section_orxIDE)"
                                      , (char*) orxConfig_GetSection(orxIDE::section_orxIDE));

  orxIDELog2Screen(orxIDE::str_output, orxIDE::spacer,"* Test - retrieve [orxIDE] section name by index ");



//orxConfig_SetStringBlock 	( 	const orxSTRING  	_zKey,
//		const orxSTRING  	_zValue)

//        orxIDELog2Screen((orxU32)   orxConfig_SetStringBlock((char*) "window", orxIDE::section_str[orxIDE::section_orxIDE])
//                          ,(char*) "orxConfig_SetStringBlock((char*) \"window\", orxIDE::section_str[orxIDE::section_orxIDE])");
//
//        orxIDELog2Screen((orxU32)   orxConfig_SetU32( "orxIDEconfig::key" , 0)
//                          ,(char*) "orxConfig_SetU32(\"orxIDEconfig::key\", 0)");

  orxIDELog2Screen(orxIDE::str_output, orxNULL, "*** end *** create config file ");

  orxIDEclear_stack();
  orxIDEConfig_Load();

  orxIDESelectSection_orxIDE();
  orxIDEGetWindow_title();

  orxIDELog2Screen(orxIDE::str_output, orxNULL, "*** End Test");
}
/// orxIDE render GUI from config file
orxSTATUS orxFASTCALL orxIDETestrender()
{
  orxIDEinitRender();
  orxIDEwindowRender();

  orxIDELog2Screen(orxIDE::str_output, orxNULL,"*** End render");

  return orxSTATUS_SUCCESS;
}
/// orx config read/write test
orxSTATUS orxFASTCALL orxIDE_Neo()
{

    BLANK_LINE
    ImGui::Separator();

    BLANK_LINE
    ImGui::Checkbox("", &orxIDEstatus::configcreate);
    ImGui::SameLine();
    ImGui::TextColored(orxIDE::red, "overwrite / initialize orxIDE Config file!");
    BLANK_LINE

    ImGui::Separator();

    if (orxIDEstatus::configcreate) {
          // reset  orxIDETestrender() flag set
          orxIDEstatus::editrender = false;
          // forget Config if file was missing / recreated
          orxIDEconfig::ConfigFileMissingFlag = false;
      }

    BLANK_LINE
    ImGui::TextColored(orxIDE::green, "Try this first!");
    ImGui::Checkbox("orxIDE Config edit - render", &orxIDEstatus::editrender);
    if (orxIDEstatus::editrender) orxIDEstatus::configcreate = false;

    if (orxIDEstatus::show_Neo) {

        BLANK_LINE

        // Child 1: no border, enable horizontal scrollbar
        // ImGui::BeginChild("Child1", ImVec2(ImGui::GetWindowContentRegionWidth() * 0.4f, 50), true, ImGuiWindowFlags_HorizontalScrollbar | (disable_mouse_wheel ? ImGuiWindowFlags_NoScrollWithMouse : 0));

        // table 2 col start
        ImGui::BeginChild("ScrollProp##001",
              ImVec2(ImGui::GetWindowContentRegionWidth() * 1.0f, 300),
              true,
              ImGuiWindowFlags_HorizontalScrollbar);
              ImGui::Columns(2, "columns##001");
              ImGui::SetColumnWidth(0, 50);

          if (orxIDEstatus::configcreate) orxIDEinitTestrender(); // automatically generate Config file
          else if (orxIDEstatus::editrender) orxIDETestrender(); // use for manual Config file edit

          ImGui::EndChild();

          ImGui::LogButtons();

          ImGui::Separator();

          BLANK_LINE

          ImGui::Text( "KEY_RCTRL %d",
              orxKeyboard_IsKeyPressed(orxKEYBOARD_KEY_RCTRL));

          ImGui::SameLine();

          ImGui::Text( "KEY_LCTRL %d",
                      orxKeyboard_IsKeyPressed(orxKEYBOARD_KEY_LCTRL));

          ImGui::SameLine();

          ImGui::Text( "LSHIFT %d",
                      orxKeyboard_IsKeyPressed(orxKEYBOARD_KEY_LSHIFT));
    }

    return orxSTATUS_SUCCESS;
}

/// ImGui multicolumn test
orxSTATUS orxFASTCALL ImGui_Test_widget()
{
    ImGui::Spacing();
//    ImGui::TextWrapped("This text should automatically wrap on the edge of the window. The current implementation for text wrapping follows simple rules suitable for English and possibly other languages.");

//    ImGui::Indent();
//    ImGui::Unindent();

//    static float wrap_width = 400.0f;
//
//    BLANK_LINE
//    ImVec2 pos = ImGui::GetCursorScreenPos();
//    ImGui::GetWindowDrawList()->AddRectFilled(ImVec2(pos.x + wrap_width, pos.y), ImVec2(pos.x + wrap_width + 10, pos.y + ImGui::GetTextLineHeight()), IM_COL32(255,0,255,255));
//    ImGui::PushTextWrapPos(ImGui::GetCursorPos().x + wrap_width);
//    ImGui::Text("%s", func_result);
//    ImGui::GetWindowDrawList()->AddRect(ImGui::GetItemRectMin(), ImGui::GetItemRectMax(), IM_COL32(255,255,0,255));
//    ImGui::PopTextWrapPos();
//

    BLANK_LINE
    ImGui::Columns(1);
    ImGui::Separator();

    ImGui::Text("Config property");
    ImGui::Columns(3, "mycolumns"); // 4-ways, with border
    ImGui::Separator();
    ImGui::Text("ID"); ImGui::NextColumn();
    ImGui::Text("Property"); ImGui::NextColumn();
    ImGui::Text("Value"); ImGui::NextColumn();
  //  ImGui::Text("Hovered"); ImGui::NextColumn();
    ImGui::Separator();
    char const * property[3] = { "One", "Two", "Three" };
    char const * value[3] = { "/path/one", "/path/two", "/path/three" };
    static int selected = -1;
    for (int i = 0; i < 3; i++)
    {
        char label[32];
        sprintf(label, "%04d", i);
        if (ImGui::Selectable(label, selected == i, ImGuiSelectableFlags_SpanAllColumns))
            selected = i;
    //    bool hovered = ImGui::IsItemHovered();
        ImGui::NextColumn();
        ImGui::Text("%s", property[i]); ImGui::NextColumn();
        ImGui::Text("%s", value[i]); ImGui::NextColumn();
    //    ImGui::Text("%d", hovered); ImGui::NextColumn();
    }
    ImGui::Columns(1);
    ImGui::Separator();
//  ImGui::TreePop();

    return orxSTATUS_SUCCESS;

}

///
orxSTATUS orxFASTCALL orxIDEConfig()
    {
#ifdef DEBUG_LOG_STREAM
    _debugFileStreamBlank();
#endif

#ifdef DEBUG_LOG_IMGUI
    ImGui::LogToFile( -1, orxIDE::ImLogFile);
#endif

//    orxLOG("\n size(arg) %d", sizeof(orxIDEf::arg));

    orxIDE_Neo();

//    ImGui_Test_widget();

    return orxSTATUS_SUCCESS;

    }

void orxFASTCALL ImGuiOrx_Style_set()
    {

    // You can pass in a reference ImGuiStyle structure to compare to, revert to and save to (else it compares to an internally stored reference)
    ImGuiStyle& style = ImGui::GetStyle();
    static ImGuiStyle ref_saved_style;

    style.FrameRounding = 3.0f; // box ,, round
    style.GrabRounding = 2.0f;

    }

//////////////////////////////////////////////////////////////////////////
orxSTATUS orxFASTCALL ImGuiOrx_Run()
    {
    ImGui_Orx_NewFrame();

    ImGui::Text("%s", (char*) ImGui::GetVersion());
    ImGui::Text(" ");

    if (orxIDEstatus::defaults_load_need) {

      ImGuiOrx_Style_set(); // box ,, round
      orxIDEstatus::defaults_load_need = false;
    }

    orxFLOAT viewport_w, viewport_h;
    orxViewport_GetSize(gpstMainViewport, &viewport_w, &viewport_h);

    // 1. Show a simple window
    // Tip: if we don't call ImGui::Begin()/ImGui::End() the widgets appears in a window automatically called "Debug"

    ImGui::Text("Hello N!");

    BLANK_LINE

    ImGui::SetNextWindowSize(ImVec2(200, 200), ImGuiCond_FirstUseEver);

    ImGui::Checkbox("Help / demo" ,&orxIDEstatus::show_demo_window );
    ImGui::Checkbox("N eo", &orxIDEstatus::show_Neo );
    ImGui::Checkbox("Style Editor", &orxIDEstatus::show_style_editor);
    ImGui::Checkbox("Show About Window", &orxIDEstatus::show_about_window);
    ImGui::Checkbox("Show Metrics Window", &orxIDEstatus::show_metrics_window);

    BLANK_LINE
    ImGui::Text("Application average %.3f ms/frame (%.1f FPS)", 1000.0f / ImGui::GetIO().Framerate, ImGui::GetIO().Framerate);

    if (orxIDEstatus::show_about_window) ImGui::ShowAboutWindow();

    if (orxIDEstatus::show_metrics_window) ImGui::ShowMetricsWindow();

    // 2. Show another simple window, this time using an explicit Begin/End pair
    if (orxIDEstatus::show_Neo )
        {
        ImGui::SetNextWindowPos(ImVec2(orxIDE::Xpos, orxIDE::Ypos));
        ImGui::SetNextWindowSize(ImVec2(orxIDE::WindowWidth, orxIDE::WindowHeigth), ImGuiCond_FirstUseEver);

        orxIDE::window_flags |= ImGuiWindowFlags_NoCollapse;
//        orxIDE::window_flags |= ImGuiWindowFlags_NoMove;
        ImGui::Begin("N eo", &orxIDEstatus::show_demo_window, orxIDE::window_flags);

/*
    if (no_titlebar)  orxIDE::window_flags |= ImGuiWindowFlags_NoTitleBar;
    if (no_scrollbar) orxIDE::window_flags |= ImGuiWindowFlags_NoScrollbar;
    if (!no_menu)     orxIDE::window_flags |= ImGuiWindowFlags_MenuBar;
    if (no_move)      orxIDE::window_flags |= ImGuiWindowFlags_NoMove;
    if (no_resize)    orxIDE::window_flags |= ImGuiWindowFlags_NoResize;
    if (no_collapse)  orxIDE::window_flags |= ImGuiWindowFlags_NoCollapse;
    if (no_nav)       orxIDE::window_flags |= ImGuiWindowFlags_NoNav;
    if (no_close)     p_open = NULL; // Don't pass our bool* to Begin
*/
        ImGui::Text("Neo version 006.004 pub");
        BLANK_LINE

        static ImVec4 TxtColor = ImColor(114, 144, 154);

        ImGuiColorEditFlags ColorEditFlags = ImGuiColorEditFlags_PickerHueWheel
                                           + ImGuiColorEditFlags_AlphaBar
                                           + ImGuiColorEditFlags_NoInputs;

//            if (!alpha) flags |= ImGuiColorEditFlags_NoAlpha; // This is by default if you call ColorPicker3() instead of ColorPicker4()
//            if (alpha_bar) flags |= ImGuiColorEditFlags_AlphaBar;
//            if (!side_preview) flags |= ImGuiColorEditFlags_NoSidePreview;
//            if (picker_mode == 1) flags |= ImGuiColorEditFlags_PickerHueBar;
//            if (picker_mode == 2) flags |= ImGuiColorEditFlags_PickerHueWheel;
//            if (inputs_mode == 1) flags |= ImGuiColorEditFlags_NoInputs;
//            if (inputs_mode == 2) flags |= ImGuiColorEditFlags_RGB;
//            if (inputs_mode == 3) flags |= ImGuiColorEditFlags_HSV;
//            if (inputs_mode == 4) flags |= ImGuiColorEditFlags_HEX;
//            ImGui::ColorPicker4("MyColor##4", (float*)&color, flags, ref_color ? &ref_color_v.x : NULL);

        ImGui::ColorEdit3((char *) "", (float*)&TxtColor, ColorEditFlags);
        ImGui::SameLine();
        ShowHelpMarker("Change color\n - Click color for color wheel\n - Click color again to change");
        ImGui::SameLine();
        ImGui::TextColored(TxtColor, "Neo ,,start");

        orxIDEConfig();

        ImGui::End();
        }

    // 3. Show the ImGui test window. Most of the sample code is in ImGui::ShowTestWindow()
    if (orxIDEstatus::show_demo_window )
        {
        ImGui::SetNextWindowPos(ImVec2(650, 20), ImGuiCond_FirstUseEver);

        ImGui::ShowDemoWindow();
        }

    if (orxIDEstatus::show_style_editor) {

      static int WindowSize2 = 300;
      ImGui::SetNextWindowPos(ImVec2(500, 400));
      ImGui::SetNextWindowSize(ImVec2(WindowSize2 * PHI, WindowSize2), ImGuiCond_FirstUseEver);

      static ImGuiWindowFlags window_flags2 = 0;
      ImGui::Begin("Style Editor", &orxIDEstatus::show_demo_window, window_flags2);
      ImGui::Text("Stylize");

      ImGui::ShowStyleEditor();
      ImGui::End();
    }

    ImGui::Render();
    return orxSTATUS_SUCCESS;
    }

//////////////////////////////////////////////////////////////////////////
void  orxFASTCALL ImGuiOrx_Exit()
    {
    ImGui_Orx_Shutdown();
    }


//#ifndef __orxMSVC__
//////////////////////////////////////////////////////////////////////////
int main(int argc, char **argv)
    {
    /* Inits and executes orx */

    // initialize widget function pointer parameter set
    orxIDEf::argStruInit();

    orx_Execute(argc, argv, ImGuiOrx_Init, ImGuiOrx_Run, ImGuiOrx_Exit);
    return EXIT_SUCCESS;
    }
