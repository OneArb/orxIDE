orxIDE test

Get started -------------------------------

1) Please download and install ImGui from https://github.com/ocornut/imgui from Dear ImGui developer Github.

2) Follow https://github.com/thegwydd/ImGuiOrx steps for ImGuiOrx installation.

3) copy /bin and /test from this archive to /ImGuiOrx

4) compile

5) more instructions on screen

--------------------------------------------

main006-004-pub.cpp demonstrates creating widgets by editing /bin/orx/orxTest.ini

orxIDEconfigParseEval() process some widgets using a switch / case for each specfic widget type

a second approach is replacing the switch statement with a single call to a function pointer array,

          orxIDEf::fp[orxIDEwidgetkey](orxIDEf::arg[orxIDEwidgetkey].text.str,
                                       orxIDEf::arg[orxIDEwidgetkey].text.fmt);

initialize its arguments within a struct union array

  orxIDEf::arg[orxIDEwidgetkey].text.str =  orxConfig_GetString(orxConfig_GetKey(orxIDEwidgetcount));

Once all widget arguments are computed for a single state, a simple array, acting as bytecode, can cycle through the widget function pointer / argument combo until the Config file changes.

The driving consideration is to explore a scripting mechanism within the config file, keywords linking to functions, in addition to widgets, through the bytecode / pointer array.
